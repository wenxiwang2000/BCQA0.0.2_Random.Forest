@echo off
REM A helper script to install dependencies and start the Streamlit app on Windows.

python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run main.py