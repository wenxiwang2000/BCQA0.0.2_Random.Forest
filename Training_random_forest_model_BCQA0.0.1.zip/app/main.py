import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import joblib
import io

st.set_page_config(page_title="Morphology RF Trainer", page_icon="🧬", layout="wide")

st.title("Morphology Random Forest Trainer")
st.write("Upload cell and non‑cell parameter CSV files to train a Random Forest classifier to distinguish cells from non‑cells. "
         "The app will split your data into training and test sets, fit the model, display evaluation metrics and plots, "
         "and let you download the trained model for later use.")

# File uploaders
cell_files = st.file_uploader(
    "📥 Upload CELL parameter CSV files (you can select multiple)", type="csv", accept_multiple_files=True
)
noncell_files = st.file_uploader(
    "📥 Upload NON‑CELL parameter CSV files (you can select multiple)", type="csv", accept_multiple_files=True
)

# Train model
if st.button("🚀 Train Random Forest"):
    if not cell_files or not noncell_files:
        st.error("Please upload at least one CSV for **cell** and one CSV for **non‑cell**.")
    else:
        try:
            # Load cell files
            cell_dfs = []
            for uploaded_file in cell_files:
                cell_dfs.append(pd.read_csv(uploaded_file))
            cell_df = pd.concat(cell_dfs, ignore_index=True)
            cell_df["Label"] = 1

            # Load non‑cell files
            non_dfs = []
            for uploaded_file in noncell_files:
                non_dfs.append(pd.read_csv(uploaded_file))
            non_df = pd.concat(non_dfs, ignore_index=True)
            non_df["Label"] = 0

            # Combine
            data = pd.concat([cell_df, non_df], ignore_index=True)

            # Use only numeric columns for features (excluding the label)
            numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
            if "Label" in numeric_cols:
                numeric_cols.remove("Label")

            if not numeric_cols:
                st.error("No numeric feature columns were found in the uploaded CSV files. Please check the files.")
            else:
                X = data[numeric_cols].fillna(0)  # handle missing values
                y = data["Label"]

                # Train/test split
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=0.2, random_state=42, stratify=y
                )

                # Train RF
                rf = RandomForestClassifier(n_estimators=100, random_state=42)
                rf.fit(X_train, y_train)

                # Predictions
                y_pred = rf.predict(X_test)
                y_prob = rf.predict_proba(X_test)[:, 1]

                # Classification report
                report_dict = classification_report(y_test, y_pred, output_dict=True)
                st.subheader("📊 Classification Report")
                st.json(report_dict)

                # Confusion matrix
                cm = confusion_matrix(y_test, y_pred)
                st.subheader("🧾 Confusion Matrix")
                fig_cm, ax_cm = plt.subplots()
                sns.heatmap(
                    cm,
                    annot=True,
                    fmt="d",
                    cmap="Blues",
                    xticklabels=["Non‑cell", "Cell"],
                    yticklabels=["Non‑cell", "Cell"],
                    ax=ax_cm,
                )
                ax_cm.set_xlabel("Predicted")
                ax_cm.set_ylabel("True")
                st.pyplot(fig_cm)

                # ROC curve
                fpr, tpr, thresholds = roc_curve(y_test, y_prob)
                roc_auc = auc(fpr, tpr)
                st.subheader("📈 ROC Curve")
                fig_roc, ax_roc = plt.subplots()
                ax_roc.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
                ax_roc.plot([0, 1], [0, 1], "k--")
                ax_roc.set_xlabel("False Positive Rate")
                ax_roc.set_ylabel("True Positive Rate")
                ax_roc.set_title("Receiver Operating Characteristic")
                ax_roc.legend(loc="lower right")
                st.pyplot(fig_roc)

                # Feature importance
                importances = rf.feature_importances_
                indices = np.argsort(importances)[::-1]
                st.subheader("🔬 Feature Importance")
                fig_imp, ax_imp = plt.subplots()
                sns.barplot(
                    x=importances[indices],
                    y=[numeric_cols[i] for i in indices],
                    ax=ax_imp,
                )
                ax_imp.set_xlabel("Importance")
                ax_imp.set_ylabel("Feature")
                st.pyplot(fig_imp)

                # Save model to bytes
                model_buffer = io.BytesIO()
                joblib.dump(rf, model_buffer)
                model_buffer.seek(0)

                st.download_button(
                    label="💾 Download Model (.joblib)",
                    data=model_buffer,
                    file_name="rf_model.joblib",
                    mime="application/octet-stream",
                )

                st.success("Model trained successfully!")
        except Exception as e:
            st.error(f"Error during processing: {e}")