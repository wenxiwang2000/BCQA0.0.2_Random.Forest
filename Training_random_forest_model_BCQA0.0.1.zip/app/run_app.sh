#!/bin/bash
# A simple helper script to install requirements and run the Streamlit app.

set -e

# Update pip and install dependencies
python -m pip install --upgrade pip
pip install -r requirements.txt

# Run the Streamlit application
streamlit run main.py