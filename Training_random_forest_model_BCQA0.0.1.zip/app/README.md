# Morphology Random Forest Trainer

This Streamlit app allows you to train a Random Forest classifier to distinguish between *cell* and *non‑cell* objects using tabular morphology feature data. Upload separate CSV files for cell and non‑cell categories, click **Train Random Forest**, and the app will:

* Combine and label your data.
* Split into train and test sets.
* Fit a RandomForestClassifier.
* Display the classification report and confusion matrix.
* Plot the ROC curve and feature importances.
* Provide a downloadable trained model (`rf_model.joblib`).

## Running the app

From the `app` directory, run the provided shell or batch script:

### Linux / Mac
```bash
chmod +x run_app.sh
./run_app.sh
```

### Windows
```cmd
run_app.bat
```

This will install the required Python packages and start the Streamlit server on your machine. Open the provided local URL in a browser to use the app.

## Input data format

Your CSV files should contain the same set of columns representing numeric features for each detected object. Each row corresponds to one object (cell or non‑cell). The files uploaded under the **cell** section are automatically labeled with `1` (cell), and the files under **non‑cell** are labeled `0`.

Any non‑numeric columns are ignored when training the model, but they remain in the uploaded DataFrame for reference.

## Output

After training, the app displays:

* A classification report with precision, recall, F1‑score, and support for each class.
* A confusion matrix heatmap.
* A ROC curve and area under the curve (AUC).
* A bar chart showing feature importances.
* A button to download the trained model (`rf_model.joblib`).